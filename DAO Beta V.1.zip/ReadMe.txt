Step 1.

Extract DAO Folder to C:\Program Files (x86)\Steam\steamapps\common\Colony Survival\gamedata\mods

If your games are installed on a different drive then you will need to replace the "C:" with the name of that drive or 
go to your steam library and right click on Colony Survival, Then Properties, Local files, and then browse local files.
After that just navigate to the following folder via this route gamedata----->mods. 

Stept 2. You're Done! You are the only one that needs to download this if you run your server too!


Made by Domn8u
Still Heavily in Progress

Contact via discord for suggestions, audio bugs, etc. at domn8u#9870